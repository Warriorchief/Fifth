from __future__ import unicode_literals

from django.apps import AppConfig


class Belt5Config(AppConfig):
    name = 'belt5'
